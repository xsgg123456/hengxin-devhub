const screens = [...document.querySelectorAll('.screen')];
const navItems = [...document.querySelectorAll('.nav-item')];
const dialog = document.querySelector('[data-dialog]');
const toast = document.querySelector('.toast');

function showScreen(id) {
  screens.forEach((screen) => screen.classList.toggle('is-active', screen.id === id));
  navItems.forEach((item) => item.classList.toggle('is-active', item.dataset.target === id));
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

function setListState(state) {
  document.querySelector('[data-state="data"]').hidden = state !== 'data';
  document.querySelector('[data-state="empty"]').hidden = state !== 'empty';
}

function setDialog(open) {
  dialog.hidden = !open;
  if (open) dialog.querySelector('input')?.focus();
}

function showToast(message) {
  toast.textContent = message;
  toast.hidden = false;
  window.setTimeout(() => { toast.hidden = true; }, 2200);
}

document.addEventListener('click', (event) => {
  const target = event.target.closest('button');
  if (!target) return;

  if (target.dataset.target) showScreen(target.dataset.target);
  if (target.dataset.action === 'show-empty') setListState('empty');
  if (target.dataset.action === 'show-data') setListState('data');
  if (target.dataset.action === 'open-dialog') setDialog(true);
  if (target.dataset.action === 'close-dialog') setDialog(false);
  if (target.dataset.action === 'complete-dialog') {
    setDialog(false);
    showToast('操作已在原型中完成');
  }
});

dialog.addEventListener('click', (event) => {
  if (event.target === dialog) setDialog(false);
});

document.addEventListener('keydown', (event) => {
  if (event.key === 'Escape' && !dialog.hidden) setDialog(false);
});

