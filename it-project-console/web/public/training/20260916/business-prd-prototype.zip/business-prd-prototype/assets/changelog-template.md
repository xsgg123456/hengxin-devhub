# PRD 与原型变更记录

> 本文件只记录变化。当前完整需求以 `Product-Spec.md` 为准，当前完整设计以 `Design-Brief.md` 为准。

## v0.1 - {{YYYY-MM-DD}} - 草案

### 新增

- 创建首版 Product Spec。
- 创建首版 Design Brief。
- 创建首版可点击原型。

### 影响

- 当前版本用于业务内部确认，尚未进入 IT 开发。

---

## {{v1.0}} - {{YYYY-MM-DD}} - {{已确认}}

### 新增

- {{新增内容，引用 REQ / SCREEN 编号。}}

### 修改

- {{从什么改成什么，引用编号和原因。}}

### 删除

- {{删除内容和原因。}}

### 影响

- 影响需求：{{SCOPE / FLOW / REQ / AC}}。
- 影响设计：{{SCREEN / CMP}}。
- 原型已同步：Yes/No。
- 是否需要重新确认：Yes/No。
- 是否需要 IT 重新评估排期：Yes/No。

