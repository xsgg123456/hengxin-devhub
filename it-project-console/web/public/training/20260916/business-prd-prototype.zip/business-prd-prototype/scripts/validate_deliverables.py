#!/usr/bin/env python3
"""Validate PRD, Design Brief, changelog, and clickable prototype consistency."""

from __future__ import annotations

import argparse
import re
import sys
import tempfile
from pathlib import Path


REQUIRED_FILES = {
    "prd": Path("Product-Spec.md"),
    "design": Path("Design-Brief.md"),
    "changelog": Path("Product-Spec-CHANGELOG.md"),
    "prototype": Path("prototype/index.html"),
    "prototype_css": Path("prototype/styles.css"),
    "prototype_js": Path("prototype/app.js"),
}

PRD_HEADINGS = (
    "文档信息",
    "业务背景",
    "目标用户与角色",
    "业务目标与成功标准",
    "范围与优先级",
    "业务流程",
    "功能需求",
    "业务规则",
    "数据与字段",
    "角色与权限",
    "异常与边界",
    "假设与待确认问题",
)

DESIGN_HEADINGS = (
    "文档信息",
    "设计目标",
    "产品结构与导航",
    "页面清单",
    "页面规格",
    "核心组件",
    "全局交互与反馈",
    "视觉方向",
    "原型覆盖矩阵",
    "假设与待确认问题",
)

PLACEHOLDER_PATTERN = re.compile(r"\[待补充\]|\bTBD\b|\bTODO\b|\{\{.+?\}\}", re.I)


def read_text(path: Path) -> str:
    return path.read_text(encoding="utf-8-sig")


def find_ids(text: str, prefix: str) -> set[str]:
    return set(re.findall(rf"\b{re.escape(prefix)}-\d{{3}}\b", text))


def heading_present(text: str, heading: str) -> bool:
    return bool(re.search(rf"^#+\s+.*{re.escape(heading)}.*$", text, re.M))


def is_confirmed(text: str) -> bool:
    return bool(re.search(r"文档状态[^\n]*已确认", text))


def validate_project(project_dir: Path) -> tuple[list[str], list[str]]:
    errors: list[str] = []
    warnings: list[str] = []
    paths = {name: project_dir / relative for name, relative in REQUIRED_FILES.items()}

    for name, path in paths.items():
        if not path.is_file():
            errors.append(f"缺少必需交付物：{path.relative_to(project_dir)}")

    if errors:
        return errors, warnings

    prd = read_text(paths["prd"])
    design = read_text(paths["design"])
    changelog = read_text(paths["changelog"])
    prototype = read_text(paths["prototype"])

    for heading in PRD_HEADINGS:
        if not heading_present(prd, heading):
            errors.append(f"Product-Spec.md 缺少章节：{heading}")

    for heading in DESIGN_HEADINGS:
        if not heading_present(design, heading):
            errors.append(f"Design-Brief.md 缺少章节：{heading}")

    prd_req_ids = find_ids(prd, "REQ")
    prd_flow_ids = find_ids(prd, "FLOW")
    prd_ac_ids = find_ids(prd, "AC")
    design_req_ids = find_ids(design, "REQ")
    design_flow_ids = find_ids(design, "FLOW")
    design_screen_ids = find_ids(design, "SCREEN")
    prototype_screen_ids = set(re.findall(r'data-screen-id=["\'](SCREEN-\d{3})["\']', prototype))
    prototype_req_ids = set(re.findall(r'data-req-id=["\'](REQ-\d{3})["\']', prototype))

    if not prd_req_ids:
        errors.append("Product-Spec.md 至少需要一个 REQ-xxx 功能编号")
    if not prd_flow_ids:
        errors.append("Product-Spec.md 至少需要一个 FLOW-xxx 流程编号")
    if not prd_ac_ids:
        errors.append("Product-Spec.md 至少需要一个 AC-xxx 验收编号")
    if not design_screen_ids:
        errors.append("Design-Brief.md 至少需要一个 SCREEN-xxx 页面编号")

    if prd_req_ids and not (prd_req_ids & design_req_ids):
        errors.append("Design-Brief.md 没有引用 Product-Spec.md 中的任何 REQ 编号")
    if prd_flow_ids and not (prd_flow_ids & design_flow_ids):
        errors.append("Design-Brief.md 没有引用 Product-Spec.md 中的任何 FLOW 编号")

    missing_screens = design_screen_ids - prototype_screen_ids
    if missing_screens:
        errors.append("原型缺少 Design Brief 页面：" + ", ".join(sorted(missing_screens)))

    unknown_screens = prototype_screen_ids - design_screen_ids
    if unknown_screens:
        warnings.append("原型包含 Design Brief 未登记页面：" + ", ".join(sorted(unknown_screens)))

    unknown_reqs = prototype_req_ids - prd_req_ids
    if unknown_reqs:
        errors.append("原型引用 PRD 中不存在的需求：" + ", ".join(sorted(unknown_reqs)))

    if "业务原型" not in prototype:
        warnings.append("prototype/index.html 未显著标明“业务原型”")

    if not re.search(r"^##\s+v?\d+\.\d+", changelog, re.M):
        errors.append("Product-Spec-CHANGELOG.md 缺少版本记录")

    for label, text in (("Product-Spec.md", prd), ("Design-Brief.md", design)):
        if is_confirmed(text):
            placeholders = PLACEHOLDER_PATTERN.findall(text)
            if placeholders:
                errors.append(f"{label} 状态为已确认，但仍包含占位符或待补充内容")
            if re.search(r"\|\s*Yes\s*\|", text) and "待确认" in text:
                warnings.append(f"{label} 状态为已确认，请人工检查是否仍有阻塞问题")

    return errors, warnings


def create_self_test_project(root: Path) -> None:
    (root / "prototype").mkdir(parents=True)
    (root / "Product-Spec.md").write_text(
        """# 产品需求文档：样例
## 0. 文档信息
| 文档状态 | 待确认 |
## 1. 业务背景
## 2. 目标用户与角色
## 3. 业务目标与成功标准
## 4. 范围与优先级
## 6. 业务流程
### FLOW-001 样例流程
## 7. 功能需求
### REQ-001 样例功能
## 8. 业务规则
## 9. 数据与字段
## 10. 角色与权限
## 11. 异常与边界
## 验收标准
- AC-001: 可观察结果
## 14. 假设与待确认问题
""",
        encoding="utf-8",
    )
    (root / "Design-Brief.md").write_text(
        """# 产品设计说明：样例
## 0. 文档信息
## 1. 设计目标与使用环境
## 2. 产品结构与导航
### 页面清单
SCREEN-001 | FLOW-001 / REQ-001
## 3. 页面规格
## 4. 核心组件
## 5. 全局交互与反馈
## 6. 视觉方向
## 8. 原型覆盖矩阵
SCREEN-001 | FLOW-001 / REQ-001
## 9. 假设与待确认问题
""",
        encoding="utf-8",
    )
    (root / "Product-Spec-CHANGELOG.md").write_text(
        "# 变更记录\n\n## v0.1 - 2026-08-16\n\n- 创建首版。\n",
        encoding="utf-8",
    )
    (root / "prototype" / "index.html").write_text(
        '<div>业务原型</div><section data-screen-id="SCREEN-001"><button data-req-id="REQ-001">操作</button></section>',
        encoding="utf-8",
    )
    (root / "prototype" / "styles.css").write_text("body { color: #111; }\n", encoding="utf-8")
    (root / "prototype" / "app.js").write_text("document.body.dataset.ready = 'true';\n", encoding="utf-8")


def run_self_test() -> int:
    with tempfile.TemporaryDirectory(prefix="business-prd-prototype-") as temp_dir:
        project_dir = Path(temp_dir)
        create_self_test_project(project_dir)
        errors, warnings = validate_project(project_dir)
        if errors:
            print("SELF-TEST FAILED")
            for error in errors:
                print(f"ERROR: {error}")
            return 1
        prd_path = project_dir / "Product-Spec.md"
        prd_path.write_text(
            prd_path.read_text(encoding="utf-8")
            .replace("| 文档状态 | 待确认 |", "| 文档状态 | 已确认 |")
            + "\n{{未清理占位符}}\n",
            encoding="utf-8",
        )
        negative_errors, _ = validate_project(project_dir)
        if not any("状态为已确认" in error for error in negative_errors):
            print("SELF-TEST FAILED: confirmed-document placeholder guard did not trigger")
            return 1
        print("SELF-TEST PASSED")
        for warning in warnings:
            print(f"WARNING: {warning}")
        return 0


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("project_dir", nargs="?", type=Path, help="包含交付物的需求项目目录")
    parser.add_argument("--self-test", action="store_true", help="运行内置校验样例")
    args = parser.parse_args()

    if args.self_test:
        return run_self_test()
    if args.project_dir is None:
        parser.error("请提供需求项目目录，或使用 --self-test")

    project_dir = args.project_dir.resolve()
    if not project_dir.is_dir():
        print(f"ERROR: 目录不存在：{project_dir}")
        return 2

    errors, warnings = validate_project(project_dir)
    for warning in warnings:
        print(f"WARNING: {warning}")
    for error in errors:
        print(f"ERROR: {error}")

    if errors:
        print(f"VALIDATION FAILED: {len(errors)} error(s), {len(warnings)} warning(s)")
        return 1

    print(f"VALIDATION PASSED: 0 error(s), {len(warnings)} warning(s)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
